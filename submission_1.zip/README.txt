To run the program, run 'python train_and_test'.

The program uses a Random Forest classifier as the main model.

Make sure to have the following dependencies installed:

python 3.8.3
pandas 1.1.0
scikit-learn 0.23.1
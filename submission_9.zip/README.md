To run the program, run `python train_and_test`.

The program uses a XGBoost (Gradient Boosting) classifier as the main model.

Make sure to have the following dependencies installed:

- python 3.8.3
- pandas 1.1.0
- numpy 1.18.5
- scikit-learn 0.23.1
- xgboost 1.1.1